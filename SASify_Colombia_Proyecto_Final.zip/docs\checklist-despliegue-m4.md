# 🚀 Checklist de Despliegue y Validación Técnica — Hito M4

> **Proyecto:** SASify Colombia — Asistente Legal de Constitución de S.A.S.  
> **Institución:** Pontificia Universidad Javeriana · Facultad de Ciencias Jurídicas  
> **Materia:** Derecho e Inteligencia Artificial (2026-II)  
> **Estudiante:** Isabella Medina Ospina  
> **Docente:** Pedro Ardila  

---

## 📋 Matriz de Verificación del Checklist de Despliegue (Rúbrica M4)

A continuación se detalla la verificación técnica y empírica de cada uno de los 4 criterios exigidos por el docente en la **Parte 4 del README**:

| Requisito Exigido por el Docente | Estado | Método de Verificación y Evidencia |
| :--- | :---: | :--- |
| **1. URL pública funcionando** | ✅ CUMPLIDO | Desplegada y accesible públicamente en GitHub Pages: **`https://isamedinao.github.io/Clase-derecho-e-IA-Javeriana-/`** (respaldo alternativo en Vercel vía `vercel.json` y GitHub Actions en `.github/workflows/pages.yml`). Probada en navegadores Google Chrome, Safari y Mozilla Firefox. |
| **2. Advertencia legal visible** | ✅ CUMPLIDO | Exhibida permanentemente en la parte superior de la aplicación mediante un banner institucional de alerta (`#fffbeb`) con borde de advertencia (`#fef3c7`). |
| **3. Cero secretos / API keys** | ✅ CUMPLIDO | Auditoría de código limpio: búsqueda exhaustiva de prefijos `sk-`, variables de autenticación o tokens privados. Resultado: **0 claves expuestas**. Toda la lógica y el motor RAG operan en el cliente en memoria volátil. |
| **4. Evidencia de usuario real** | ✅ CUMPLIDO | Registro documentado en [`docs/evidencia-usuario.md`](evidencia-usuario.md) con el testimonio, métricas y calificaciones del emprendedor Carlos Andrés Gómez. |

---

## 🔍 Detalle de Cada Criterio

### 1. Verificación de URL Pública
* **URL Principal (GitHub Pages):**  
  👉 **`https://isamedinao.github.io/Clase-derecho-e-IA-Javeriana-/`**
* **Mecanismo de Despliegue Automatizado:**  
  Se configuró el flujo de integración continua en `.github/workflows/pages.yml`, el cual detecta cualquier actualización en la rama `main` y compila los artefactos estáticos automáticamente sin requerir intervención manual ni servidores de pago.
* **Compatibilidad Multiplataforma:**  
  La interfaz fue diseñada con diseño responsivo (`styles.css` con *media queries* para móviles y escritorio), permitiendo que cualquier usuario abra la herramienta desde su teléfono o computador.

---

### 2. Texto Exacto de la Advertencia Visible (Salvaguarda Ética)
En cumplimiento estricto de las directrices del curso y de la Ley 1581 de 2012 (Habeas Data), el encabezado de la aplicación proyecta de manera fija:

> ⚠️ **Aviso Legal Obligatorio:** *Esta herramienta es un ejercicio académico de la Pontificia Universidad Javeriana. **No constituye asesoría legal profesional** ni sustituye la consulta y revisión final de un abogado titulado. No ingreses datos personales sensibles reales (Ley 1581 de 2012).*

Adicionalmente, el asistente reitera esta advertencia en su mensaje de bienvenida y activa salvaguardas éticas inmediatas frente a intentos de consulta tributaria o registro de marcas.

---

### 3. Auditoría de Seguridad y Protección de Datos
Se ejecutó un análisis de seguridad sobre la totalidad del repositorio:
1. **Búsqueda de API Keys (`sk-`, `key`, `secret`, `token`):** Negativo. No se requiere ni se incluye ninguna credencial de pago ni privada.
2. **Almacenamiento de Datos:** La aplicación no utiliza bases de datos remotas, cookies de rastreo ni almacenamiento persistente en servidores externos. Al refrescar o cerrar la pestaña del navegador, los datos ingresados se destruyen de la memoria RAM.
3. **Respeto a la Ley 1581 de 2012:** El sistema instruye explícitamente al usuario a utilizar denominaciones e identidades societarias ficticias durante la simulación.

---

### 4. Funcionalidades Verificadas en Producción
1. **Flujo de 5 Pasos (Art. 5 Ley 1258/08):** Denominación, socios fundadores (unipersonal o plural), objeto social (indeterminado o específico), capital y representación legal.
2. **Generador de Estatutos en Tiempo Real:** Redacción simultánea en el panel derecho debidamente numerada por capítulos y artículos con citas legales.
3. **Pestaña de Corpus Normativo (RAG):** Buscador semántico con resaltado de términos sobre la Ley 1258/08, Código de Comercio y Decreto 1074/15.
4. **Herramientas de Salida:** Botones funcionales para **Copiar al portapapeles**, **Descargar archivo .txt** e **Imprimir / Exportar a PDF** con formato contractual limpio.
