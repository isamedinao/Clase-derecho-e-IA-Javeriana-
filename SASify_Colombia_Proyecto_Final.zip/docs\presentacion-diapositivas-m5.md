# 📑 Diapositivas de Presentación (Sustentación Final de 5 Minutos) — Hito M5

> **Proyecto:** SASify Colombia — "Constituye tu SAS con estatutos claros, citando la ley y en minutos"  
> **Estudiante:** Isabella Medina Ospina  
> **Curso:** Derecho e Inteligencia Artificial (2026-II) · Pontificia Universidad Javeriana  
> **Docente:** Pedro Ardila  
> **Tiempo total:** 5 minutos cronometrados  

---

## 🖥️ Diapositiva 1: Portada y Título (Minuto 0:00 - 0:30)

### **SASify Colombia**
#### *Constituye tu SAS con estatutos claros, citando la ley y en minutos*
* **Estudiante:** Isabella Medina Ospina
* **Materia:** Derecho e Inteligencia Artificial
* **Docente:** Pedro Ardila
* **Pontificia Universidad Javeriana — Facultad de Ciencias Jurídicas**
* **Repositorio:** [github.com/isamedinao/Clase-derecho-e-IA-Javeriana-](https://github.com/isamedinao/Clase-derecho-e-IA-Javeriana-)

---

## 🖥️ Diapositiva 2: El Problema Jurídico Real (Minuto 0:30 - 1:15)

### **La Brecha en la Constitución de Sociedades en Colombia**
* **La promesa de la Ley 1258 de 2008:** Crear empresas ágiles por documento privado.
* **La realidad del emprendedor primerizo:**
  1. **Altos costos iniciales:** Honorarios notariales y de asesoría ($1.500.000+ COP) inalcanzables para startups en etapa temprana.
  2. **Plantillas ciegas de internet:** Minutas desactualizadas, confusas o sin sustento normativo.
  3. **Formularios a ciegas:** Desconocimiento crítico sobre capital autorizado vs. suscrito vs. pagado, órganos obligatorios y causales de disolución.
* **Consecuencia:** Empresas que nacen con riesgos societarios y cláusulas inválidas ante Cámara de Comercio.

---

## 🖥️ Diapositiva 3: Arquitectura Técnica y RAG (Minuto 1:15 - 2:15)

### **La Solución: Asistente Legal-Tech Guiado con RAG Positivo**
* **¿Por qué un chat estándar fracasa?** Los LLM genéricos alucinan normas foráneas o inventan artículos inexistentes.
* **Nuestra Arquitectura RAG (*Retrieval-Augmented Generation*):**
  * **Corpus Normativo Oficial:** Ley 1258 de 2008 (completa), Decreto 410 de 1971 (Código de Comercio) y Decreto 1074 de 2015.
  * **Recuperación Positiva:** Antes de redactar cada cláusula, el sistema extrae el artículo exacto (Art. 5, 9, 25, 26, 28).
  * **Generador en Vivo:** Escribe el borrador simultáneamente al diálogo del usuario.

---

## 🖥️ Diapositiva 4: Demostración en Vivo de la Interfaz (Minuto 2:15 - 3:15)

### **Demostración Práctica (index.html / GitHub Pages)**
* **Panel Izquierdo:** Diálogo guiado en 5 pasos (Art. 5 Ley 1258/08):
  1. Denominación ("S.A.S.") y Domicilio.
  2. Accionistas fundadores (unipersonal o plural).
  3. Objeto social (opción de objeto indeterminado, Art. 5 num. 5).
  4. Capital autorizado, suscrito y pagado (plazo de 2 años, Art. 9).
  5. Órganos de administración (sin junta directiva ni revisor fiscal obligatorios, Arts. 25 y 28).
* **Panel Derecho:** Visualizador en vivo con botones de **Copiar**, **Descargar** e **Imprimir / Guardar en PDF**.
* **Pestaña RAG:** Biblioteca legal interactiva para auditar el texto de la ley en tiempo real.

---

## 🖥️ Diapositiva 5: Salvaguardas Éticas y Prueba de Usuario Real (Minuto 3:15 - 4:15)

### **Responsabilidad Jurídica y Validación Empírica**
* **Salvaguardas Éticas Implementadas:**
  * ⚠️ **Aviso legal visible:** Ejercicio académico, no sustituye al abogado.
  * 🛑 **Límite de alcance tributario y de marcas:** Rechazo automático de consultas sobre IVA, DIAN y registros ante la SIC.
  * 🔒 **Protección de Datos (Ley 1581/2012):** Procesamiento local en navegador sin bases de datos remotas.
* **Prueba con Usuario Real (Carlos Andrés Gómez, 29 años - Emprendedor):**
  * Proyecto simulado: *"Miga & Grano S.A.S."*
  * Tiempo de redacción: **14 minutos** (frente a semanas de trámite convencional).
  * Calificación de usabilidad: **5/5 estrellas**.

---

## 🖥️ Diapositiva 6: Análisis Crítico y Conclusión (Minuto 4:15 - 5:00)

### **¿Por qué SASify Colombia NO reemplaza al Abogado?**
* **La IA resuelve la carpintería documental:** Automatiza la redacción estándar del artículo 5.
* **El valor insustituible del abogado:**
  * **Estrategia y previsión de conflictos:** Pactos parasociales complejos (*drag-along*, *tag-along*, *vesting*).
  * **Aportes solemnes:** Estudio de títulos e inmuebles sujetos a escritura pública.
  * **Responsabilidad ética y civil:** Juicio prudencial que ningún algoritmo asume.
* **Conclusión:** SASify Colombia democratiza el acceso a estatutos transparentes y permite que el jurista se enfoque en el asesoramiento estratégico de alto impacto.
